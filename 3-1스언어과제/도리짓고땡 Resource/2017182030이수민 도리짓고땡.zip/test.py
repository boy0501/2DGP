from itertools import combinations
import random

lst = [5,7,3]

lst.sort()


print(lst)

